## The work and writing for [Mig Reyes](http://mig.pizza)

### About Mig:
I’m a graphic and product designer from Chicago, leading design at [Trunk Club](http://trunkclub.com) and serving as President for [AIGA Chicago](http://chicago.aiga.org). Before Trunk Club, I shaped brand and product for [Basecamp](http://github.com/basecamp) (_formerly 37signals_) and Threadless.

=====

### About this site:
This site is hand made with [Jekyll](http://jekyllrb.com) using Sass and CoffeeScript for assets. These are my template files to build everything at http://mig.pizza. Feel free to poke around to get ideas for your next Jekyll project.

=====

Elsewhere:  
http://twitter.com/migreyes  
http://instagram.com/migreyes

=====

Thanks for visiting.