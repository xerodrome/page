---
title: Out of Layer Tennis Retirement
preview: I’ve been keeping my design skills sharp during the offseason to once again step foot on the Layer Tennis courts.
---

[![Layer Tennis is back. Finally](/assets/images/blog/lyt.jpg)](http://layertennis.com/match/koxvold-vs.-reyes)

After a few years of endlessly boring Fridays, the fine folks at Coudal and Adobe have teamed up once again to bring us [Layer Tennis](http://layertennis.com). With rookie design prospects looking to break onto the [#LYT4 big leagues](https://twitter.com/search?q=%23LYT4&src=typd) along side veteran creative powerhouses, this season’s Layer Tennis looks to pick up right where we left off.

And what better way to kick it off than [a friendly exhibition match](http://layertennis.com/match/koxvold-vs.-reyes) as I play against New York’s [Jason Koxvold](http://koxvold.com), with play-by-play commentary from one of my favorite writers, [Alissa Walker](http://awalkerinla.com).

The first match starts today at 11:30am. Root for me. Or don’t—either way, enjoy the show.