---
title: "Reminder: Design is still about words"
category: writes
// svn: 3404
medium: reminder-design-is-still-about-words-c8ea79e6b8ca
favorite: true
preview: Proof that design starts with having something to say, not draw
---
Click away from the pen tool…

Put down your Pantone book…

Stop rearranging your layers…

Close your stock texture folder…

Log out of your Dribbble…

And god dammit, hug your copywriter…

Designing for the web is still about words.